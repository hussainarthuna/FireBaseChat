package com.codechat.hussain.codechat;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainChatActivity extends AppCompatActivity {

    private String myUserName;
    private ListView myChatList;
    private EditText myChatText;
    private ImageButton mySend;
    private DatabaseReference myDataBaseRef;

    private ChatListAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_chat);

        setUpDisplayName();
        myDataBaseRef=FirebaseDatabase.getInstance().getReference();

        myChatList=(ListView)findViewById(R.id.chat_list_view);
        myChatText=(EditText)findViewById(R.id.messageInput);
        mySend=(ImageButton)findViewById(R.id.sendButton);

        mySend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                pushToFirebase();
            }
        });


        myChatText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                pushToFirebase();
                return true;
            }
        });



    }


    @Override
    protected void onStart() {
        super.onStart();

        myAdapter=new ChatListAdapter(this,myDataBaseRef,myUserName);
        myChatList.setAdapter(myAdapter);
    }

    @Override
    protected void onStop() {
        super.onStop();

        myAdapter.freeUpResources();
    }

    private void pushToFirebase(){

        String chatInput=myChatText.getText().toString();
        if(!chatInput.equals("")){


            InstantMessage chat= new InstantMessage(chatInput,myUserName);
            myDataBaseRef.child("chats").push().setValue(chat);
            myChatText.setText("");
        }
        else {
            Toast.makeText(getApplicationContext(),"Please Enter the Message",Toast.LENGTH_SHORT).show();
        }
    }


    private void setUpDisplayName(){
        SharedPreferences preferences=getSharedPreferences(RegisterActivity.CHAT_REF,MODE_PRIVATE);
        myUserName=preferences.getString(RegisterActivity.DISPLAY_NAME,null);


        if(myUserName == null){

            myUserName="user";

        }
    }
}
