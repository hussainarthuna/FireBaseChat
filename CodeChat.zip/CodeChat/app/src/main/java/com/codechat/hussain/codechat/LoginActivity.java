package com.codechat.hussain.codechat;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.common.data.SingleRefDataBufferIterator;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    EditText myEmail,myPassword;
    Button login,register;
    private FirebaseAuth myAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myEmail=(EditText)findViewById(R.id.login_email);
        myPassword=(EditText)findViewById(R.id.login_password);
        login=(Button)findViewById(R.id.login_signin);
        register=(Button)findViewById(R.id.login_register);

        myAuth=FirebaseAuth.getInstance();
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loginFirebase();
            }
        });
    }

    private void showErrorBox(String message){
        new AlertDialog.Builder(this)
                .setTitle("ERROR")
                .setMessage(message)
                .setPositiveButton(android.R.string.ok,null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void loginFirebase(){
        String email=myEmail.getText().toString();
        String password=myPassword.getText().toString();

        myAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(!task.isSuccessful()){
                    showErrorBox("Something went wrong");
                }
                else {

                    Intent intent=new Intent(getApplicationContext(),MainChatActivity.class);
                    finish();
                    startActivity(intent);
                }
            }
        });
    }
}
