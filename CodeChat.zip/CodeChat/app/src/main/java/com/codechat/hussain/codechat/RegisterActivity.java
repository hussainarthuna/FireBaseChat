package com.codechat.hussain.codechat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    public static final String CHAT_REF="ChatPref";
    public static final String DISPLAY_NAME="Username";

    private AutoCompleteTextView myUsername;
    private EditText myEmail,myPassword,myConfirmPassword;
    private Button register;


    private FirebaseAuth myAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        myEmail=(EditText)findViewById(R.id.register_email);
        myUsername=(AutoCompleteTextView) findViewById(R.id.register_username);
        myPassword=(EditText)findViewById(R.id.register_password);
        myConfirmPassword=(EditText)findViewById(R.id.register_confirm);

        myAuth=FirebaseAuth.getInstance();

        register=(Button)findViewById(R.id.register_signup);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                registerUser();
            }
        });
    }

    private void showErrorBox(String message){
        new AlertDialog.Builder(this)
                .setTitle("ERROR")
                .setMessage(message)
                .setPositiveButton(android.R.string.ok,null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void saveUserName(){
        String username=myUsername.getText().toString();
        SharedPreferences preferences=getSharedPreferences(CHAT_REF,0);
        preferences.edit().putString(DISPLAY_NAME,username).apply();
    }

    private void createUser(){
        String email=myEmail.getText().toString();
        String password=myPassword.getText().toString();
        myAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                Log.d("DEBUG_CODE","OnCompletere was"+task.isSuccessful());
                if(!task.isSuccessful())
                {
                    showErrorBox("Registration Failed");

                }
                else {
                    saveUserName();
                    Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                    finish();
                    startActivity(intent);
                }

            }
        });

    }

    private boolean validateEmail(String email){
        return email.contains("@");

    }

    private boolean validatePassword(String pass){
        String confpass=myConfirmPassword.getText().toString();
        return confpass.equals(pass) && pass.length() > 4;
    }

    private void registerUser(){
        myEmail.setError(null);
        myPassword.setError(null);
        myConfirmPassword.setError(null);
        myUsername.setError(null);
        String email=myEmail.getText().toString();
        String password=myPassword.getText().toString();
        boolean cancel=false;
        View focusView=null;

        if(!TextUtils.isEmpty(password) && !validatePassword(password)){

            myPassword.setError(getString(R.string.invalid_password));
            focusView=myPassword;
            cancel=true;
        }

        if(!TextUtils.isEmpty(email) && !validateEmail(email)){

            myEmail.setError(getString(R.string.invalid_email));
            focusView=myEmail;
            cancel=true;

        }

        if(cancel){
            focusView.requestFocus();
        }
        else {
            createUser();
        }
    }
}
